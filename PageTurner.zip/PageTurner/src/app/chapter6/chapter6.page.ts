import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chapter6',
  templateUrl: './chapter6.page.html',
  styleUrls: ['./chapter6.page.scss'],
})
export class Chapter6Page implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
